// frontend/src/components/landing/ContactSection.tsx
import React, { useState } from 'react';
import apiClient from '../../api/client';
import { useSiteSettings } from '../../hooks/useSiteSettings';

const ContactSection = () => {
    const { data: settings } = useSiteSettings();
    const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
    const [status, setStatus] = useState({ submitting: false, success: false, error: '' });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setStatus({ submitting: true, success: false, error: '' });
        try {
            await apiClient.post('/feedback', formData);
            setStatus({ submitting: false, success: true, error: '' });
            setFormData({ name: '', email: '', subject: '', message: '' });
        } catch (err: any) {
            setStatus({ submitting: false, success: false, error: err.response?.data?.message || 'Failed to send message.' });
        }
    };

    return (
        <section id="contact" className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
            <div className="text-center mb-16">
                <h2 className="text-4xl font-bold text-dark-text dark:text-dark-text-dark">{settings?.contactPage?.title}</h2>
                <p className="mt-4 text-light-text dark:text-light-text-dark max-w-2xl mx-auto">{settings?.contactPage?.subtitle}</p>
            </div>
            <div className="grid md:grid-cols-2 gap-16 max-w-6xl mx-auto">
                <div className="bg-light-card dark:bg-dark-card p-8 rounded-2xl shadow-lg border border-border-color dark:border-border-color-dark">
                    <h3 className="text-2xl font-bold text-dark-text dark:text-dark-text-dark mb-6">{settings?.contactPage?.formTitle}</h3>
                    <form onSubmit={handleSubmit} className="space-y-5">
                        {/* Form fields with updated styling */}
                        <div>
                            <label htmlFor="name" className="block text-sm font-medium text-light-text dark:text-light-text-dark">Full Name</label>
                            <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 w-full p-3 bg-light-bg dark:bg-dark-bg border border-border-color dark:border-border-color-dark rounded-lg text-dark-text dark:text-dark-text-dark focus:ring-brand-primary focus:border-brand-primary transition-all"/>
                        </div>
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-light-text dark:text-light-text-dark">Email Address</label>
                            <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} required className="mt-1 w-full p-3 bg-light-bg dark:bg-dark-bg border border-border-color dark:border-border-color-dark rounded-lg text-dark-text dark:text-dark-text-dark focus:ring-brand-primary focus:border-brand-primary transition-all"/>
                        </div>
                        <div>
                            <label htmlFor="subject" className="block text-sm font-medium text-light-text dark:text-light-text-dark">Subject</label>
                            <input type="text" name="subject" id="subject" value={formData.subject} onChange={handleChange} required className="mt-1 w-full p-3 bg-light-bg dark:bg-dark-bg border border-border-color dark:border-border-color-dark rounded-lg text-dark-text dark:text-dark-text-dark focus:ring-brand-primary focus:border-brand-primary transition-all"/>
                        </div>
                        <div>
                            <label htmlFor="message" className="block text-sm font-medium text-light-text dark:text-light-text-dark">Message</label>
                            <textarea name="message" id="message" value={formData.message} onChange={handleChange} required rows={5} className="mt-1 w-full p-3 bg-light-bg dark:bg-dark-bg border border-border-color dark:border-border-color-dark rounded-lg text-dark-text dark:text-dark-text-dark focus:ring-brand-primary focus:border-brand-primary transition-all"></textarea>
                        </div>
                        <button type="submit" disabled={status.submitting} className="w-full bg-brand-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-brand-secondary disabled:opacity-50 transition-colors duration-200">
                            {status.submitting ? 'Sending...' : 'Send Message'}
                        </button>
                        {status.success && <p className="text-brand-secondary transition-all">Message sent successfully!</p>}
                        {status.error && <p className="text-brand-orange transition-all">{status.error}</p>}
                    </form>
                </div>
                <div className="space-y-8 text-light-text dark:text-light-text-dark">
                    {settings?.contactPage?.addresses?.map((addr, index) => (
                        <div key={index} className="bg-light-card dark:bg-dark-card p-6 rounded-xl border border-border-color dark:border-border-color-dark shadow-sm transition-all duration-200">
                            <h4 className="text-xl font-bold text-brand-primary dark:text-brand-secondary">{addr.locationName}</h4>
                            <p className="mt-2 text-dark-text dark:text-dark-text-dark">{addr.fullAddress}</p>
                            <p>Phone: {addr.phone}</p>
                            <p>Email: {addr.email}</p>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default ContactSection;
