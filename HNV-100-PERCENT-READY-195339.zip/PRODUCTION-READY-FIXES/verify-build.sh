#!/bin/bash
echo "🔍 Verifying production build..."

# Check if all required files exist
if [ ! -f "dist/index.html" ]; then
  echo "❌ Build failed: index.html not found"
  exit 1
fi

if [ ! -d "dist/assets" ]; then
  echo "❌ Build failed: assets directory not found"
  exit 1
fi

# Check bundle sizes
echo "📊 Bundle analysis:"
du -sh dist/assets/*.js | head -5
echo "✅ Build verification complete"
