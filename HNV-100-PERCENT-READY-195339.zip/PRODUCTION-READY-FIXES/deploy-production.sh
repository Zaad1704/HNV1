#!/bin/bash
set -e

echo "🚀 Starting production deployment..."

# Install dependencies
echo "📦 Installing dependencies..."
npm ci --production=false

# Type check
echo "🔍 Type checking..."
npm run type-check

# Build for production
echo "🏗️ Building for production..."
npm run build:prod

# Verify build
echo "✅ Verifying build..."
./verify-build.sh

echo "🎉 Production build complete!"
echo "📁 Files ready in ./dist/"
